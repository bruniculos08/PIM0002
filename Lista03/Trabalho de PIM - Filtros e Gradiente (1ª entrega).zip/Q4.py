# Alunos: Bruno R. dos Santos e Pedro Vargas T.
import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt
from math import *
from Q3 import *

def direction(pixels_x_derivative : np.ndarray, pixels_y_derivative : np.ndarray) -> np.ndarray:
    pixels_direction = np.zeros_like(pixels_x_derivative, dtype=np.float64)
    epsilon = 10 ** (-8)
    for y in range(0, len(pixels_direction)):                                         
        for x in range(0, len(pixels_direction[0])):
            pixels_direction[y][x] = np.arctan(pixels_y_derivative[y][x]/(pixels_x_derivative[y][x] + epsilon))
            # Obs.: a função np.arctan retorna valores entre -pi/2 e -pi/2.   
    return pixels_direction

if __name__ == "__main__":
    np.set_printoptions(suppress = True)
    np.set_printoptions(linewidth=np.inf)

    image_name = "Lua1_gray"
    image_path = "Imagens/" + image_name
    image_ext = "jpg"

    pixels_x_derivative = xAxisDerivative(image_path, image_ext, sobel_x)
    pixels_y_derivative = yAxisDerivative(image_path, image_ext, sobel_y)
    pixels_direction = direction(pixels_x_derivative, pixels_y_derivative)

    saveImage(image_path + "-Directionteste" + '.' + image_ext, pixels_direction)